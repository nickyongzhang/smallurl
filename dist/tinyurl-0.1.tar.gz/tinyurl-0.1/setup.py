from distutils.core import setup

setup(
	name = 'tinyurl',
	version = '0.1',
	packages = ['tinyURL',],
	license = 'MIT licenced',
	long_description = open('README.md').read()
	)

