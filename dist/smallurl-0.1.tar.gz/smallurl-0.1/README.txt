The project is aimed at changing a long URL to a tiny url.

We usesually see some ugly and long urls in emails or 
somewhere else like

https://www.amazon.com/BLACK-DECKER-LCC140-Lithium-Trimmer/dp/B00JGUAP8W/ref=gbps_img_s-3_5402_77b2d6e0?smid=ATVPDKIKX0DER&pf_rd_p=2558495402&pf_rd_s=slot-3&pf_rd_t=701&pf_rd_i=gb_main&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=KZRQ9PST7PV2YR29SHFT

It would be a nightmare if we want to cut such a url. How about changing the long url into a tiny url which directs to the same direction? That what this little project is doing.

Actually this project is using the service provided the website Tinyurl.com. The website can return a tiny url if the user input a long url. Our project provides a simple script to get access to the website's service without opening the browsers. It's easy and portable.