from distutils.core import setup

setup(
	name = 'smallurl',
	version = '0.1',
	packages = ['smallURL',],
	license = 'MIT licenced',
	long_description = open('README.md').read()
	)

